const thundra = require('@thundra/core');
const opentracing = require('opentracing')
var AWS = require('aws-sdk');
var dynamodb = new AWS.DynamoDB();
let tableName = "shieldStore";
var datetime = new Date().getTime().toString();
let input;

var addHero = function(event){
    const globalTracer = opentracing.globalTracer();
    const span = globalTracer.startSpan('addHero');
    return new Promise(function(resolve,reject){
        
        var params = {
            "TableName": tableName,
            "Item":{
                "hero" : { S: event.hero},
                "timedate" : {N: datetime}
            }
        }
        dynamodb.putItem(params, function(err,data){
            span.setTag('msg',data);
            span.finish();
            if(err){
                return reject(err);
            }else{
                return resolve(data);
            }
        });
    });
}

var getHero = function(event){
    const globalTracer = opentracing.globalTracer();
    const span = globalTracer.startSpan('retrieveList');
    return new Promise(function(resolve, reject){
        var params = {
            "TableName" : tableName
        }
        dynamodb.scan(params, function(err,data){
            span.setTag('msg',data);
            span.finish();
            if(err){
                return reject(err);
            }else{
                return resolve(data);
            }
        });
    });
}

exports.handler = thundra()((event, context, callback) => {
    var tracer = thundra.tracer();
    opentracing.initGlobalTracer(tracer);
    
    const globalTracer = opentracing.globalTracer();
    const span = globalTracer.startSpan('checkAndAddHero');
    getHero(event).then(
        (results) => {
            var found = false;
            var items = results.Items;
            for (i = 0; i < items.length; i++){
                if(items[i].hero.S == event.hero){
                    span.setTag('msg','Hero exists');
                    span.finish();
                    console.log(JSON.stringify(items[i].hero));
                    context.succeed("Hero has already been enlisted");
                }
            }
            addHero(event).then((results) =>{
                    span.setTag('msg','Hero enlisted');
                    span.finish();
                context.succeed("Enlisted");
            }).catch(
                (err)=> {
                    span.setTag('msg',err);
                    span.finish();
                    context.fail("Could not add member- " + err);
            })
        }).catch(
            (err) =>{
                span.setTag('msg',err);
                span.finish();
                context.fail('ERRROR ' + err)
        })
});