const thundra = require("@thundra/core");
const AWS = require('aws-sdk');
const opentracing = require('opentracing');

var sheildDatabse = new AWS.DynamoDB();
let tableName = "shieldStore";
var datetime = new Date().getTime().toString();

function checkIfExists(event, callback){
    var scanParams = {
        "TableName": tableName
    }
}

function addHero(event, callback) {

    const globalTracer = opentracing.globalTracer();
    const span = globalTracer.startSpan('addHero');
    var params = {
        "TableName": tableName,
        "Item":{
            "hero" : { S: event.hero},
            "timedate" : {N: datetime}
        }
    }

    sheildDatabse.putItem(params, function(err, data){
        span.setTag('msg',data);
        span.finish();
        if(err){
            callback(err, null);
        }else {
            console.log('Dynamo Success: ' + JSON.stringify(data, null, ' '));
            callback(null, "SUCCESS");
        }
       
    });  
}

exports.handler = thundra()((event, context, callback) => {
    var tracer = thundra.tracer();
    opentracing.initGlobalTracer(tracer);

    addHero(event, callback);
});