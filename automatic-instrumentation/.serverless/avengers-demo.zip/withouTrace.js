console.log('Loading event');
const thundra = require('@thundra/core');
const opentracing = require('opentracing')
var AWS = require('aws-sdk');
var dynamodb = new AWS.DynamoDB();
let tableName = "shieldStore";
var datetime = new Date().getTime().toString();
let input;

const config = {
	apiKey:'ce7e63db-3a96-4372-81be-6863945d7c86',
	traceConfig : {
		traceDefs: [{
			pattern : 'dynamoExample.index.*', //Defines what functions to monitor
		}],
	},
};

var addHero = function(event){
    return new Promise(function(resolve,reject){
        var params = {
            "TableName": tableName,
            "Item":{
                "hero" : { S: event.hero},
                "timedate" : {N: datetime}
            }
        }
        dynamodb.putItem(params, function(err,data){
            if(err){
                return reject(err);
            }else{
                return resolve(data);
            }
        });
    });
}

var getHero = function(event){
    return new Promise(function(resolve, reject){
        var params = {
            "TableName" : tableName
        }
        dynamodb.scan(params, function(err,data){
            if(err){
                return reject(err);
            }else{
                return resolve(data);
            }
        });
    });
}

exports.handler = thundra(config)((event, context, callback) => {
    
    getHero(event).then(
        (results) => {
            var found = false;
            var items = results.Items;
            for (i = 0; i < items.length; i++){
                if(items[i].hero.S == event.hero){
                    console.log(JSON.stringify(items[i].hero));
                    context.succeed("Hero has already been enlisted");
                }
            }
            addHero(event).then((results) =>{
                context.succeed("Enlisted");
            }).catch(
                (err)=> {
                    context.fail("Could not add member- " + err);
            })
        }).catch(
            (err) =>{
                context.fail('ERRROR ' + err)
        })
});